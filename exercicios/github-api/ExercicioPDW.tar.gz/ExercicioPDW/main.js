// 1. Selecionando os elementos da DOM
const input = document.querySelector('input[name="username"]');
const main = document.querySelector('main');

// Função de Debounce (conforme a dica do exercício)
function callbackComAdiamento(funcaoParaExecutar, tempoEspera) {
  let temporizador;
  
  return function (event) {
    clearTimeout(temporizador);
    
    // Passamos o "event" para dentro da função que será executada
    temporizador = setTimeout(() => {
      funcaoParaExecutar(event);
    }, tempoEspera);
  };
}

// 2. Funções auxiliares de interface (Preloader, Limpeza e Erros)
function showPreloader() {
  // Exibimos um texto simples, mas você poderia colocar a tag <img> de um SVG aqui
  main.innerHTML = '<p class="preloader">⏳ Buscando usuário no GitHub...</p>';
}

function clearMain() {
  main.innerHTML = '';
}

function clearError() {
  // Remove a mensagem de erro caso ela exista na tela
  const errorMessage = document.querySelector('.error-message');
  if (errorMessage) {
    errorMessage.remove();
  }
}

function showError(mensagem) {
  clearError();
  // Cria e insere uma mensagem de erro logo após o input (no <header>)
  const p = document.createElement('p');
  p.className = 'error-message';
  p.style.color = 'red';
  p.textContent = mensagem;
  input.insertAdjacentElement('afterend', p);
}

// 3. Função para exibir o usuário (Fulfilled)
function renderUser(user) {
  clearMain();
  
  // Criação do cartão usando a DOM API
  const card = document.createElement('div');
  card.className = 'card';
  
  // Usamos template strings para preencher os dados
  card.innerHTML = `
    <img src="${user.avatar_url}" alt="Foto de ${user.name}" width="150" style="border-radius: 50%;">
    <h2>${user.name ? user.name : user.login}</h2>
    <p><strong>Repositórios públicos:</strong> ${user.public_repos}</p>
    <p><strong>Seguidores:</strong> ${user.followers}</p>
    <p><strong>Seguindo:</strong> ${user.following}</p>
    <a href="${user.html_url}" target="_blank">Acessar perfil</a>
  `;
  
  main.appendChild(card);
}

// 4. Função principal assíncrona que consome a API do GitHub
async function pegaUsuarioGitHub(event) {
  const username = event.target.value.trim(); // Pega o que o usuário digitou e remove os espaços
  
  clearError();
  
  // Se o campo estiver vazio, limpamos a tela e paramos a execução
  if (username === '') {
    clearMain();
    return;
  }
  
  showPreloader(); // Pending: mostra o carregamento
  
  try {
    const resposta = await fetch(`https://api.github.com/users/${username}`);
    
    // Dica do exercício: checar se a resposta não foi ok (ex: 404)
    if (!resposta.ok) {
      throw new Error("Usuário não encontrado.");
    }
    
    const dados = await resposta.json();
    
    renderUser(dados); // Fulfilled: sucesso, mostra os dados
    
  } catch (erro) {
    console.error(erro); // Loga o erro no console
    clearMain(); // Remove o preloader do main
    showError("Não foi possível localizar este usuário. Verifique o nome e tente novamente."); // Rejected: exibe mensagem ao usuário
  }
}

// 5. Adicionando o EventListener com Debounce
// Executa a busca apenas 500ms depois que o usuário parar de digitar
input.addEventListener("input", callbackComAdiamento(pegaUsuarioGitHub, 500));